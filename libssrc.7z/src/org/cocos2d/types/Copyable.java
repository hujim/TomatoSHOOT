package org.cocos2d.types;

public interface Copyable {
    public Object copy();
}
