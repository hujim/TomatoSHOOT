package org.cocos2d.types;

/** A vertex composed of 3 floats: x, y, z
 @since v0.8
 */
public class ccVertex3F {
    float x;
    float y;
    float z;
}

