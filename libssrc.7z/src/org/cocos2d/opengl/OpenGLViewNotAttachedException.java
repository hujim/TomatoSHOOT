package org.cocos2d.opengl;

public class OpenGLViewNotAttachedException extends Exception {
    public OpenGLViewNotAttachedException(String reason) {
        super(reason);
    }
}
