package org.cocos2d.opengl;

public class OpenGLViewCantDetachException extends Exception {
    public OpenGLViewCantDetachException(String reason) {
    }
}
