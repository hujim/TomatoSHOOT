package org.mirlab.tomatoshoot;

import java.util.LinkedList;

import org.cocos2d.layers.CCColorLayer;
import org.cocos2d.layers.CCScene;
import org.cocos2d.menus.CCMenu;
import org.cocos2d.menus.CCMenuItemImage;
import org.cocos2d.nodes.CCDirector;
import org.cocos2d.nodes.CCLabel;
import org.cocos2d.nodes.CCSprite;
import org.cocos2d.sound.SoundEngine;
import org.cocos2d.transitions.CCFlipAngularTransition;
import org.cocos2d.transitions.CCFlipXTransition;
import org.cocos2d.transitions.CCTransitionScene.tOrientation;
import org.cocos2d.types.CGPoint;
import org.cocos2d.types.CGSize;
import org.cocos2d.types.ccColor3B;
import org.cocos2d.types.ccColor4B;
import org.mirlab.facebook.mirfb;

import com.facebook.android.DialogError;
import com.facebook.android.FacebookError;
import com.facebook.android.Facebook.DialogListener;

import android.content.Context;
import android.os.Bundle;
import android.util.Log;

public class SetGameItemLayer extends CCColorLayer {
	protected int currentLayer = -1;	
	private LinkedList<SubBtnLayer> _weaponLayers;
	private LinkedList<SubBtnLayer> _armorLayers;	
	private int haveWeaponSelectedNum, haveArmorSelectedNum;				
	
	protected CCLabel _label1;
	protected CCLabel _label2;
	
	mirfb FB;
	protected MIRFighter tomatoFighter;
	
	Context context = CCDirector.sharedDirector().getActivity();
	
	static CCScene scene;
	public static CCScene scene()
	{
		scene = CCScene.node();
		scene.setTag(1);
		CCColorLayer layer = new SetGameItemLayer(ccColor4B.ccc4(255, 255, 255, 255));
				
		scene.addChild(layer);		
				
		return scene;
	}
	
	protected SetGameItemLayer(ccColor4B color) {
		super(color);
		
		this.setIsTouchEnabled(true);
		
		FB = ((TomatoshootGame)CCDirector.sharedDirector().getActivity()).FB;
		tomatoFighter = ((TomatoshootGame)CCDirector.sharedDirector().getActivity()).tomatoFighter;
		
		CGSize winSize = CCDirector.sharedDirector().displaySize();
		CCSprite background = CCSprite.sprite("background_store_com.png");		
		
		// �̷ӭI���Ϧ��Y����ҥh�վ��L�Ϥ������Y���
		float backgroundScale = winSize.height/(background.getTextureRect().size.height);
		//float backgroundScale = winSize.width/(background.getTextureRect().size.width);
		
		background.setPosition(CGPoint.ccp(winSize.width / 2.0f, winSize.height / 2.0f));
		background.setScale(backgroundScale);
		addChild(background);
		
		///////
		_label1 = CCLabel.makeLabel("None", "Arial", 25);
		_label1.setColor(ccColor3B.ccBLACK);
		_label1.setPosition(winSize.width * 3 / 4.0f, winSize.height / 2.0f + 40);		
		addChild(_label1);
		_label2 = CCLabel.makeLabel("None", "Arial", 25);
		_label2.setColor(ccColor3B.ccBLACK);
		_label2.setPosition(winSize.width * 3 / 4.0f, winSize.height / 2.0f);		
		addChild(_label2);
		
		// �]�w�ϥΪ�		
		//tomatoFighter = new MIRFighter("YuJhe", 9999);		
		tomatoFighter.addOwnWeapons(indexOfWeapon2String(0));
		tomatoFighter.addOwnWeapons(indexOfWeapon2String(1));
		tomatoFighter.addOwnWeapons(indexOfWeapon2String(2));
		tomatoFighter.addOwnWeapons(indexOfWeapon2String(3));
		tomatoFighter.addOwnProps(indexOfArmor2String(0));
		
		// �Z���B����B�䴩�B�W�@���B�U�@�������s		
		CCMenuItemImage weaponBtn = CCMenuItemImage.item("button_weapon_com.png", "button_weapon_com.png", this, "clickMenuBtn");		
		weaponBtn.setScale(backgroundScale);
		weaponBtn.setTag(0);
		
		CGSize btnSize = weaponBtn.getContentSize();			
		btnSize.width = weaponBtn.getContentSize().width * backgroundScale;		
		btnSize.height = weaponBtn.getContentSize().height * backgroundScale;
		
		CCMenuItemImage armorBtn = CCMenuItemImage.item("button_armor_com.png", "button_armor_com.png", this, "clickMenuBtn");
		armorBtn.setScale(backgroundScale);
		armorBtn.setTag(1);
		
		CCMenuItemImage audioBtn = CCMenuItemImage.item("button_cloth_com.png", "button_cloth_com.png", this, "clickMenuBtn");		
		audioBtn.setScale(backgroundScale);
		audioBtn.setTag(2);
		
		CCMenu btnMenu = CCMenu.menu(weaponBtn, armorBtn, audioBtn);		
		btnMenu.setColor(ccColor3B.ccc3(255, 255, 255));
		btnMenu.setPosition(CGPoint.ccp(btnSize.width * 2.5f, winSize.height - btnSize.height * 1.3f));
		btnMenu.alignItemsHorizontally(20);
		addChild(btnMenu);	
		
		/*		
		CCMenuItemImage backwardBtn = CCMenuItemImage.item("backward.png", "backward.png", this, "clickMenuBtn");
		backwardBtn.setScale(backgroundScale);
		backwardBtn.setTag(3);
					
		CCMenuItemImage nextBtn = CCMenuItemImage.item("next.png", "next.png", this, "clickMenuBtn");
		nextBtn.setScale(backgroundScale);
		nextBtn.setTag(4);
		
		CCMenu btnMenu = CCMenu.menu(backwardBtn, weaponBtn, armorBtn, audioBtn, nextBtn);		
		btnMenu.setColor(ccColor3B.ccc3(255, 255, 255));
		btnMenu.setPosition(CGPoint.ccp(winSize.width * 0.75f - btnSize.width * 2.0f, winSize.height / 3.0f));
		btnMenu.alignItemsVertically(5);
		//btnMenu.alignItemsHorizontally(20);
		addChild(btnMenu);			
		*/
		
		
		// �U�@�����s
		CCMenuItemImage nextBtn = CCMenuItemImage.item("button_next.png", "button_next.png", this, "clickMenuBtn");
		nextBtn.setScale(backgroundScale);
		nextBtn.setTag(3);
		
		CCMenu nextBtnMenu = CCMenu.menu(nextBtn);
		nextBtnMenu.setColor(ccColor3B.ccc3(255, 255, 255));
		nextBtnMenu.setPosition(CGPoint.ccp(btnSize.width * 4.8f, winSize.height / 2.0f));
		addChild(nextBtnMenu);		
		
		
		// Facebook ���s		
		//**
		//FB = new mirfb(CCDirector.sharedDirector().getActivity());
		
		CCMenuItemImage fbBtn = CCMenuItemImage.item("faceBook_icon.png", "faceBook_icon.png", this, "clickMenuBtn");
		fbBtn.setScale(backgroundScale);
		fbBtn.setTag(5);
		
		CCMenu fbBtnMenu = CCMenu.menu(fbBtn);
		fbBtnMenu.setColor(ccColor3B.ccc3(255, 255, 255));
		fbBtnMenu.setPosition(CGPoint.ccp(btnSize.width * 4.8f, winSize.height *2.0f / 3.0f));		
		addChild(fbBtnMenu);		
		
		if (tomatoFighter.getOwnWeapons().size() == 1) {
			
		} else if (tomatoFighter.getOwnWeapons().size() == 2) {
			
		} else if (tomatoFighter.getOwnWeapons().size() == 3) {
			
		} else if (tomatoFighter.getOwnWeapons().size() == 4) {		
			SubBtnLayer weaponLayer = new SubBtnLayer(
					"button_"+tomatoFighter.getOwnWeapons().get(0)+"_unselected.png", "button_"+tomatoFighter.getOwnWeapons().get(0)+"_selected.png",
					"button_"+tomatoFighter.getOwnWeapons().get(1)+"_unselected.png", "button_"+tomatoFighter.getOwnWeapons().get(1)+"_selected.png", 
					"button_"+tomatoFighter.getOwnWeapons().get(2)+"_unselected.png", "button_"+tomatoFighter.getOwnWeapons().get(2)+"_selected.png",
					"button_"+tomatoFighter.getOwnWeapons().get(3)+"_unselected.png", "button_"+tomatoFighter.getOwnWeapons().get(3)+"_selected.png" 					
					);
			
			weaponLayer.setTag(1);
			weaponLayer.setAllBtnTag(2);
			weaponLayer.setMaxSelectedItemNum(2);
			weaponLayer.setCurSelectedItemNum(0);	
			
			_weaponLayers = new LinkedList<SubBtnLayer>();
			_weaponLayers.add(weaponLayer);
		} else if (tomatoFighter.getOwnWeapons().size() == 5) {
			
		} else if (tomatoFighter.getOwnWeapons().size() == 6) {
			
		} else if (tomatoFighter.getOwnWeapons().size() == 7) {
			
		} else if (tomatoFighter.getOwnWeapons().size() == 8) {
			
		} else if (tomatoFighter.getOwnWeapons().size() == 9 ) {
			
		}
				
		if (tomatoFighter.getOwnProps().size() == 1) {
			SubBtnLayer propLayer = new SubBtnLayer(
					"button_"+tomatoFighter.getOwnProps().get(0)+"_unselected.png", "button_"+tomatoFighter.getOwnProps().get(0)+"_selected.png"					
					);
			
			propLayer.setTag(1);
			propLayer.setAllBtnTag(2);
			propLayer.setMaxSelectedItemNum(2);
			propLayer.setCurSelectedItemNum(0);	
			
			_armorLayers = new LinkedList<SubBtnLayer>();
			_armorLayers.add(propLayer);
		} else if (tomatoFighter.getOwnProps().size() == 2) {
			
		} else if (tomatoFighter.getOwnProps().size() == 3) {
			
		} else if (tomatoFighter.getOwnProps().size() == 4) {		

		} else if (tomatoFighter.getOwnWeapons().size() == 5) {
			
		} else if (tomatoFighter.getOwnWeapons().size() == 6) {
			
		} else if (tomatoFighter.getOwnWeapons().size() == 7) {
			
		} else if (tomatoFighter.getOwnWeapons().size() == 8) {
			
		} else if (tomatoFighter.getOwnWeapons().size() == 9 ) {
			
		}		
		/*
		SubBtnLayer weaponLayer01 = new SubBtnLayer(
				"button_corn_unselected.png", "button_corn_selected.png", "button_grape_unselected.png", "button_grape_selected.png", "button_pineapple_unselected.png", "button_pineapple_selected.png", 
				"button_watermelon_unselected.png", "button_watermelon_selected.png"//, "button_unselected.png", "button_selected.png", "button_unselected.png", "button_selected.png", 
				//"button_unselected.png", "button_selected.png", "button_unselected.png", "button_selected.png", "button_unselected.png", "button_selected.png"
				);		
		weaponLayer01.setTag(1);
		weaponLayer01.setAllBtnTag(2);
		weaponLayer01.setMaxSelectedItemNum(2);
		weaponLayer01.setCurSelectedItemNum(0);
		
		_weaponLayers = new LinkedList<SubBtnLayer>();
		_weaponLayers.add(weaponLayer01);
				
		SubBtnLayer armorLayer01 = new SubBtnLayer(
				"button_corn_unselected.png", "button_corn_selected.png", "button_grape_unselected.png", "button_grape_selected.png", "button_pineapple_unselected.png", "button_pineapple_selected.png", 
				"button_watermelon_unselected.png", "button_watermelon_selected.png", "button_unselected.png", "button_selected.png", "button_unselected.png", "button_selected.png", 
				"button_unselected.png", "button_selected.png", "button_unselected.png", "button_selected.png", "button_unselected.png", "button_selected.png"
				);	
		armorLayer01.setTag(1);
		armorLayer01.setAllBtnTag(2);
		armorLayer01.setMaxSelectedItemNum(2);
		armorLayer01.setCurSelectedItemNum(0);
		
		SubBtnLayer armorLayer02 = new SubBtnLayer(
				"button_unselected.png", "button_selected.png", "button_unselected.png", "button_selected.png", "button_unselected.png", "button_selected.png", 
				"button_unselected.png", "button_selected.png", "button_unselected.png", "button_selected.png", "button_unselected.png", "button_selected.png", 
				"button_unselected.png", "button_selected.png", "button_unselected.png", "button_selected.png", "button_unselected.png", "button_selected.png"	
				);
		armorLayer02.setTag(0);
		armorLayer02.setAllBtnTag(2);
		armorLayer02.setMaxSelectedItemNum(2);
		armorLayer02.setCurSelectedItemNum(0);
		
		_armorLayers = new LinkedList<SubBtnLayer>();
		_armorLayers.add(armorLayer01);
		_armorLayers.add(armorLayer02);
		*/
		
		// Handle sound
		//
		SoundEngine.sharedEngine().preloadEffect(context, R.raw.pew_pew_lei);
		SoundEngine.sharedEngine().preloadEffect(context, R.raw.next);
		//SoundEngine.sharedEngine().setSoundVolume(1f);
		//SoundEngine.sharedEngine().playSound(context, R.raw.background_music_aac, true);
		
		this.schedule("update");		
	}
	
	public void clickMenuBtn(Object sender) {
		CCMenuItemImage item = (CCMenuItemImage) sender;		
		
		//Context context = CCDirector.sharedDirector().getActivity();
		
		if (item.getTag() == 0) {		//	Click weapon button
			SoundEngine.sharedEngine().playEffect(context, R.raw.pew_pew_lei);
			if (currentLayer == 0) {
				//	Nothing
			} else if (currentLayer == 1) {
				for (SubBtnLayer _armorLayer : _armorLayers) {
					if (_armorLayer.getTag() == 1) {												
						removeChild(_armorLayer, true);
						break;
					}
				}
								
				for (SubBtnLayer _weaponLayer : _weaponLayers) {
					if (_weaponLayer.getTag() == 1) {
						addChild(_weaponLayer);
						break;
					}
				}				
			} else if (currentLayer == 2) {
				// 
				//	do something facebook
				//
				
				for (SubBtnLayer _weaponLayer : _weaponLayers) {
					if (_weaponLayer.getTag() == 1) {
						addChild(_weaponLayer);
						break;
					}
				}								
			} else {				
				for (SubBtnLayer _weaponLayer : _weaponLayers) {
					if (_weaponLayer.getTag() == 1) {
						addChild(_weaponLayer);
						break;
					}
				}
			}
											
			currentLayer = 0;					
		} else if (item.getTag() == 1) {		// Click armor button
			SoundEngine.sharedEngine().playEffect(context, R.raw.pew_pew_lei);			
			
			if (currentLayer == 0) {
				for (SubBtnLayer _weaponLayer : _weaponLayers) {
					if (_weaponLayer.getTag() == 1) {						
						removeChild(_weaponLayer, true);
						break;
					}					
				}
				
				for (SubBtnLayer _armorLayer : _armorLayers) {
					if (_armorLayer.getTag() == 1) {
						addChild(_armorLayer);
						break;
					}
				}				
			} else if (currentLayer == 1) {
				//	Nothing
			} else if (currentLayer == 2) {
				///
				///	do something facebook
				///
				
				for (SubBtnLayer _armorLayer : _armorLayers) {
					if (_armorLayer.getTag() == 1) {
						addChild(_armorLayer);
						break;
					}
				}																
			} else {				
				for (SubBtnLayer _armorLayer : _armorLayers) {
					if (_armorLayer.getTag() == 1) {
						addChild(_armorLayer);
						break;
					}
				}
			}
											
			currentLayer = 1;				
		} else if (item.getTag() == 2) {		//	Click audio button
			if (currentLayer == 0) {
				for (SubBtnLayer _weaponLayer : _weaponLayers) {
					if (_weaponLayer.getTag() == 1) {						
						removeChild(_weaponLayer, true);
						break;
					}					
				}
				
				///
				///	do something facebook 
				///
/*				if (FB.is_login()) {
					_label1.setString("FB login");
				} else {
					_label1.setString("FB not login");
				}
*/				
			} else if (currentLayer == 1) {
				for (SubBtnLayer _armorLayer : _armorLayers) {
					if (_armorLayer.getTag() == 1) {
						removeChild(_armorLayer, true);
						break;
					}
				}
				
				///
				///	do something facebook 
				///		
/*				if (FB.is_login()) {
					_label1.setString("FB login");
				} else {
					_label1.setString("FB not login");
				}
*/				
			} else if (currentLayer == 2) {							
				//	Nothing
			} else {				
				///
				///	do something facebook 
				///	
/*				if (FB.is_login()) {
					_label1.setString("FB login");
				} else {
					_label1.setString("FB not login");
				}				
*/
			}
			
			currentLayer = 2;
		} else if (item.getTag() == 3) {		//	Click next button
			int layerIndex = 0;
			
			if (currentLayer == 0) {
				SoundEngine.sharedEngine().playEffect(context, R.raw.next);
				
				for (SubBtnLayer _weaponLayer : _weaponLayers) {
					if (_weaponLayer.getTag() == 1) {						
						_weaponLayer.setTag(0);
						removeChild(_weaponLayer, true);
						layerIndex = _weaponLayers.indexOf(_weaponLayer);						
						break;
					}
				}
								
				addChild(_weaponLayers.get((layerIndex+1) % _weaponLayers.size()));
				_weaponLayers.get((layerIndex+1) % _weaponLayers.size()).setTag(1);
			} else if (currentLayer == 1) {
				SoundEngine.sharedEngine().playEffect(context, R.raw.next);
				
				for (SubBtnLayer _armorLayer : _armorLayers) {
					if (_armorLayer.getTag() == 1) {						
						_armorLayer.setTag(0);
						removeChild(_armorLayer, true);
						layerIndex = _armorLayers.indexOf(_armorLayer);
						break;
					}
				}
				
				addChild(_armorLayers.get((layerIndex+1) % _armorLayers.size()));
				_armorLayers.get((layerIndex+1) % _armorLayers.size()).setTag(1);				
			} else if (currentLayer == 2) {				
				///
				///	do something facebook
				///
			}		
			//CCDirector.sharedDirector().replaceScene(GameLayer.scene()); //Temp Start game
			
			item.setIsEnabled(false);
			CCDirector.sharedDirector().replaceScene(CCFlipAngularTransition.transition(1, GameLayerLV07.scene(), tOrientation.kOrientationRightOver));
			SoundEngine.sharedEngine().realesAllSounds();
			SoundEngine.sharedEngine().setSoundVolume(0.5f);
			SoundEngine.sharedEngine().playSound(context, R.raw.mr_reno, true);
			
		} else if (item.getTag() == 5) {		//	Click facebook icon
			_label1.setString("facebook");
						
			DialogListener a=new DialogListener() {
	            @Override
	            public void onComplete(Bundle values) {
	            	//FB.get_me() is required
	            	Log.e("fbbbbbbb",FB.get_me().toString());            	
	            }

	            @Override
	            public void onFacebookError(FacebookError error) {
	            	Log.e("fbbbbbbb","login error:" + error.toString() );
	            }

	            @Override
	            public void onError(DialogError e) {
	            	Log.e("fbbbbbbb","error:"+ e.toString());
		        }

	            @Override
	            public void onCancel() {
	            	Log.e("fbbbbbbb","login: cancel");
		        }
	        };
	        Log.e("@@@@", (FB==null)? "null" :"not null");
			FB.login(a);			
			
			_label1.setString("facebook@@");	
			//_label1.setString(TomatoStoreView.tomatoFighter.getID());
			/*
			TomatoStoreView.FB.login(new DialogListener() {
	            @Override
	            public void onComplete(Bundle values) {
	            	_label1.setString("login:u r already login");
	            	
	            	//FB.get_me() is required
	            	_label1.setString(TomatoStoreView.FB.get_me().toString());	            	
	            }

	            @Override
	            public void onFacebookError(FacebookError error) {
	            	_label1.setString("login error:" + error.toString() );
	            }

	            @Override
	            public void onError(DialogError e) {
	            	_label1.setString("error:"+ e.toString());
		        }

	            @Override
	            public void onCancel() {
	            	_label1.setString("login: cancel");
		        }
	        });			
			*/
		}
	}
	
	public void update(float ft) {
		int [] selectedItemIndex;
		int count = 0;
		_label1.setString("None");
		_label2.setString("None");
		tomatoFighter.setSelectedWeapon1("");
		tomatoFighter.setSelectedWeapon2("");
		
		this.haveWeaponSelectedNum = 0;
		for (SubBtnLayer _weaponLayer : _weaponLayers) {
			this.haveWeaponSelectedNum += _weaponLayer.getSelectedItemNum();
			
			selectedItemIndex = _weaponLayer.getSelectedIndex();
			for (int i = 0; i < selectedItemIndex.length;i++) {
				if (selectedItemIndex[i] == 1) {
					if (count == 0) {
						//Log.d("index", "index1 :" + indexOfWeapon2String(i));
						tomatoFighter.setSelectedWeapon1(indexOfWeapon2String(i));
						_label1.setString("" + _weaponLayers.indexOf(_weaponLayer)*9 + i);
						count += 1;
						//Log.d("YJ", "Selected : " + tomatoFighter.getSelectedWeapons().getFirst());
					} else if (count == 1) {
						tomatoFighter.setSelectedWeapon2(indexOfWeapon2String(i));
						//Log.d("index", "index2 :" + indexOfWeapon2String(i));
						_label2.setString("" + _weaponLayers.indexOf(_weaponLayer)*9 + i);						
						count += 1;
						//Log.d("YJ", "Selected : " + tomatoFighter.getSelectedWeapons().getFirst());
						//Log.d("YJ", "Selected : " + tomatoFighter.getSelectedWeapons().get(1));
					}								
				}
			}
		}			
		
		for (SubBtnLayer _weaponLayer : _weaponLayers) {
			_weaponLayer.setHaveSelectedItemNum(this.haveWeaponSelectedNum);
		}			
		
		this.haveArmorSelectedNum = 0;		
		tomatoFighter.setSelectedArmor1("");
		tomatoFighter.setSelectedArmor2("");
		count = 0;
		
		for (SubBtnLayer _armorLayer : _armorLayers) {
			this.haveArmorSelectedNum += _armorLayer.getSelectedItemNum();	
			
			selectedItemIndex = _armorLayer.getSelectedIndex();
			for (int i = 0; i < selectedItemIndex.length;i++) {
				if (selectedItemIndex[i] == 1) {
					if (count == 0) {
						//Log.d("index", "index1 :" + indexOfWeapon2String(i));
						tomatoFighter.setSelectedArmor1(indexOfArmor2String(i));
						_label1.setString("" + _armorLayers.indexOf(_armorLayer)*9 + i);
						count += 1;
						//Log.d("YJ", "Selected : " + tomatoFighter.getSelectedWeapons().getFirst());
					} else if (count == 1) {
						tomatoFighter.setSelectedArmor2(indexOfArmor2String(i));
						//Log.d("index", "index2 :" + indexOfWeapon2String(i));
						_label2.setString("" + _armorLayers.indexOf(_armorLayer)*9 + i);						
						count += 1;
						//Log.d("YJ", "Selected : " + tomatoFighter.getSelectedWeapons().getFirst());
						//Log.d("YJ", "Selected : " + tomatoFighter.getSelectedWeapons().get(1));
					}								
				}
			}
			
		}						
		
		for (SubBtnLayer _armorLayer : _armorLayers) {
			_armorLayer.setHaveSelectedItemNum(this.haveArmorSelectedNum);
		}
	}
	
	public MIRFighter getTomato() {
		return this.tomatoFighter;
	}
	
	//	weapon index ��Ӫ�
	public String indexOfWeapon2String(int index) {
		if (index == 0) return "corn";
		else if (index == 1) return "grape";
		else if (index == 2) return "pineapple";
		else if (index == 3) return "watermelon";
		else return "tomato";
	}
	
	//	armor index ��Ӫ�
	public String indexOfArmor2String(int index) {
		if (index == 0) return "aim";
		else return "tomato";
	}	
	@Override
	public void onExit() {
		//SoundEngine.sharedEngine().realesAllSounds();
		//SoundEngine.sharedEngine().setSoundVolume(0.5f);
		//SoundEngine.sharedEngine().playSound(context, R.raw.mr_reno, true);
		
		super.onExit();
		
	}
}
