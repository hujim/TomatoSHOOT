package org.mirlab.tomatoshoot;

import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;

import org.cocos2d.actions.instant.CCCallFunc;
import org.cocos2d.actions.interval.CCDelayTime;
import org.cocos2d.actions.interval.CCRotateBy;
import org.cocos2d.actions.interval.CCSequence;
import org.cocos2d.layers.CCColorLayer;
import org.cocos2d.layers.CCScene;
import org.cocos2d.menus.CCMenu;
import org.cocos2d.menus.CCMenuItem;
import org.cocos2d.menus.CCMenuItemSprite;
import org.cocos2d.nodes.CCDirector;
import org.cocos2d.nodes.CCLabel;
import org.cocos2d.nodes.CCSprite;
import org.cocos2d.nodes.CCSpriteFrameCache;
import org.cocos2d.opengl.CCBitmapFontAtlas;
import org.cocos2d.sound.SoundEngine;
import org.cocos2d.transitions.CCFadeTransition;
import org.cocos2d.transitions.CCFlipAngularTransition;
import org.cocos2d.transitions.CCFlipXTransition;
import org.cocos2d.transitions.CCTransitionScene.tOrientation;
import org.cocos2d.types.CGPoint;
import org.cocos2d.types.CGSize;
import org.cocos2d.types.ccColor3B;
import org.cocos2d.types.ccColor4B;
import org.mirlab.SpeechRecognition.pitchRecorder;
import org.mirlab.facebook.mirfb;
import org.mirlab.tomatoshoot.R;

import android.util.Log;
import android.view.MotionEvent;
import org.json.JSONObject;
import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.hardware.Camera;
import android.os.Bundle;


import com.facebook.android.*;
import com.facebook.android.Facebook.*;

public class GameStartLayer extends CCColorLayer
{
	protected CCBitmapFontAtlas _label;
	protected CGSize winSize;
	mirfb FB;
	Camera mCamera;
	
	ArrayList<String> IdList = new ArrayList<String>(); 
	ArrayList<String> NameList = new ArrayList<String>(); 
	Bitmap mIcon1 = null;
	URL img_value = null;
	pitchRecorder volThRecorder;
	Thread volThThread;
	CCMenuItemSprite start,process_btn,rank_btn,music_btn,store_btn,arrow_btn,youtube_btn,FB_btn;
	boolean processOpen,arrowOpen;
	
	GameStartLayer layer;
	static CCScene scene;
	public static CCScene scene()
	{
		scene = CCScene.node();
		scene.setTag(0);
		GameStartLayer layer = new GameStartLayer(ccColor4B.ccc4(255, 255, 255, 255));
		layer.setTag(0);
		//layer.getLabel().setString(message);
		
		scene.addChild(layer);
		
		return scene;
	}
	
	public CCBitmapFontAtlas getLabel()
	{
		return _label;
	}
	
	@SuppressWarnings("deprecation")
	protected GameStartLayer(ccColor4B color)
	{
		super(color);
		
		this.setIsTouchEnabled(true);
		
		FB = ((TomatoshootGame)CCDirector.sharedDirector().getActivity()).FB;
		mCamera = ((TomatoshootGame)CCDirector.sharedDirector().getActivity()).mCamera;
		
		winSize = CCDirector.sharedDirector().displaySize();
		
		_label = CCBitmapFontAtlas.bitmapFontAtlas("Tomato Shoot!", "Arial.fnt");
		_label.setColor(ccColor3B.ccBLACK);
		_label.setScale(1.5f);
		_label.setPosition(CGPoint.ccp(winSize.width * 0.5f, winSize.height * 0.8f));
		addChild(_label);
		
		start = CCMenuItemSprite.item(
				CCSprite.sprite("tomato.png"), 
				CCSprite.sprite("tomato.png"), this, "clickStart");
		start.setScale(winSize.height/(4f*start.getContentSize().height));
		start.setTag(0);
		process_btn = CCMenuItemSprite.item(
				CCSprite.sprite("process.png"), 
				CCSprite.sprite("process.png"), this, "clickTool");
		process_btn.setTag(1);
		rank_btn = CCMenuItemSprite.item(
				CCSprite.sprite("ranking.png"), 
				CCSprite.sprite("ranking.png"), this, "clickTool");
		rank_btn.setTag(2);
		rank_btn.setScale(0.6f);
		rank_btn.setVisible(false);
		music_btn = CCMenuItemSprite.item(
				CCSprite.sprite("music.png"), 
				CCSprite.sprite("music.png"), this, "clickTool");
		music_btn.setTag(3);
		music_btn.setScale(0.6f);
		music_btn.setVisible(false);
		store_btn = CCMenuItemSprite.item(
				CCSprite.sprite("store.png"), 
				CCSprite.sprite("store.png"), this, "clickTool");
		store_btn.setTag(4);
		store_btn.setScale(0.6f);
		store_btn.setVisible(false);
		arrow_btn = CCMenuItemSprite.item(
				CCSprite.sprite("arrow.png"), 
				CCSprite.sprite("arrow.png"), this, "clickNet");
		arrow_btn.setTag(5);
		youtube_btn = CCMenuItemSprite.item(
				CCSprite.sprite("youtube.png"), 
				CCSprite.sprite("youtube.png"), this, "clickNet");
		youtube_btn.setTag(6);
		youtube_btn.setScale(0.6f);
		youtube_btn.setVisible(false);
		FB_btn = CCMenuItemSprite.item(
				CCSprite.sprite("FB.png"), 
				CCSprite.sprite("FB.png"), this, "clickNet");
		FB_btn.setTag(7);
		FB_btn.setScale(0.6f);
		FB_btn.setVisible(false);
		
		CCMenu startMenu = CCMenu.menu(start);		
		startMenu.setColor(ccColor3B.ccc3(255,255,255));
		startMenu.setPosition(CGPoint.ccp(winSize.width / 2.0f, winSize.height / 2.0f));
		startMenu.alignItemsVertically(5);
		addChild(startMenu,100);	
		CCMenu toolMenu = CCMenu.menu(store_btn,music_btn,rank_btn,process_btn);		
		toolMenu.setColor(ccColor3B.ccc3(255,255,255));
		toolMenu.setPosition(CGPoint.ccp(winSize.width * 0.1f, winSize.height * 0.25f));
		toolMenu.alignItemsVertically(5);
		addChild(toolMenu,102);
		CCMenu netMenu = CCMenu.menu(FB_btn,youtube_btn,arrow_btn);		
		netMenu.setColor(ccColor3B.ccc3(255,255,255));
		netMenu.setPosition(CGPoint.ccp(winSize.width * 0.9f, winSize.height * 0.22f));
		netMenu.alignItemsVertically(5);
		addChild(netMenu,102);	

		processOpen = false;
		arrowOpen = false;
		if(FB.is_login())
			friendMenu();
		
		Camera.Parameters parameters = mCamera.getParameters();
    	parameters.setColorEffect(Camera.Parameters.EFFECT_SEPIA); 
        mCamera.setParameters(parameters);       
		
        playBMG();
    }
	public static void playBMG()
	{
		 SoundEngine.sharedEngine().realesAllSounds();
	     SoundEngine.sharedEngine().setSoundVolume(100f);
		 SoundEngine.sharedEngine().playSound(CCDirector.sharedDirector().getActivity(), R.raw.this_is_honkstep, true);		
		
	}
	
	public void gameStartDone()
	{
		//CCDirector.sharedDirector().replaceScene(GameLayer.scene());
		CCDirector.sharedDirector().end();
	}
	public void clickStart(Object sender)
	{		
		CCMenuItem item = (CCMenuItem) sender;
		
		if(item.getTag() == 0 ) 
		{
			CCDirector.sharedDirector().replaceScene(CCFlipAngularTransition.transition(1, SetGameItemLayer.scene(), tOrientation.kOrientationRightOver));
			//CCDirector.sharedDirector().replaceScene(CCFlipAngularTransition.transition(1, StoreLayer.scene(), tOrientation.kOrientationRightOver));
			//CCDirector.sharedDirector().replaceScene(SetGameItemLayer.scene());
		}

	}
	public void clickTool(Object sender){
		CCMenuItem item = (CCMenuItem) sender;
		if(item.getTag() == 1 ) 
		{
			if(processOpen == false){
				item.setRotation(0);
				item.runAction(CCRotateBy.action(0.5f, 360));
				this.store_btn.setVisible(true);
				this.music_btn.setVisible(true);
				this.rank_btn.setVisible(true);
				processOpen = true;
			}
			else{
				item.runAction(CCRotateBy.action(0.5f, -360));
				this.store_btn.setVisible(false);
				this.music_btn.setVisible(false);
				this.rank_btn.setVisible(false);
				processOpen = false;
			}
			
		}
		else if(item.getTag() == 2 ) 
		{
			
		}
		else if(item.getTag() == 3 ) 
		{
			
		}
		else if(item.getTag() == 4 ) 
		{
			
		}
	}
	public void clickNet(Object sender){
		CCMenuItem item = (CCMenuItem) sender;
		if(item.getTag() == 5){
			if(arrowOpen == false){
				item.setRotation(0);
				item.runAction(CCRotateBy.action(0.5f,180));
				this.FB_btn.setVisible(true);
				this.youtube_btn.setVisible(true);
				arrowOpen = true;
			}
			else{
				item.runAction(CCRotateBy.action(0.5f,-180));
				this.FB_btn.setVisible(false);
				this.youtube_btn.setVisible(false);
				arrowOpen = false;
			}
		}
		else if(item.getTag() == 6){
			
		}
		else if(item.getTag() == 7){
			_label.setString("facebook");					
			DialogListener fbDialog=new DialogListener() {
	            @Override
	            public void onComplete(Bundle values) {
	            	//FB.get_me() is required
	            	//Log.e("fbbbbbbb",FB.get_me().toString());  
	            	IdList = FB.get_friendFieldArray("id");
	            	NameList = FB.get_friendFieldArray("name");
	            	friendMenu();
	            	
	            }

	            @Override
	            public void onFacebookError(FacebookError error) {
	            	//Log.e("fbbbbbbb","login error:" + error.toString() );
	            }

	            @Override
	            public void onError(DialogError e) {
	            	//Log.e("fbbbbbbb","error:"+ e.toString());
		        }

	            @Override
	            public void onCancel() {
	            	//Log.e("fbbbbbbb","login: cancel");
		        }
	        };
	        //Log.e("@@@@", (FB==null)? "null" :"not null");
			FB.login(fbDialog);
		}
	}
	@SuppressWarnings("deprecation")
	public void friendMenu(){
		IdList = FB.get_friendFieldArray("id");
    	NameList = FB.get_friendFieldArray("name");
		CCMenuItemSprite[] friendItem = new CCMenuItemSprite[5];
		for(int i = 0;i < 5;i++){
			try {
				img_value = new URL("http://graph.facebook.com/" + this.IdList.get(i) + "/picture");
				mIcon1 = BitmapFactory.decodeStream(img_value.openConnection().getInputStream());
			} catch (Exception e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			friendItem[i] = CCMenuItemSprite.item(
					CCSprite.sprite(mIcon1), 
					CCSprite.sprite(mIcon1), this, "clickStart");
			friendItem[i].setTag(i+2);
			
		}
		CCMenu friendMenu = CCMenu.menu(friendItem);		
		friendMenu.setColor(ccColor3B.ccc3(255,255,255));
		friendMenu.setPosition(CGPoint.ccp(winSize.width / 2.0f, 50.0f));
		friendMenu.alignItemsHorizontally(5);
		addChild(friendMenu,102);	
		
	}
	@Override
	public boolean ccTouchesEnded(MotionEvent event)
	{
		//gameOverDone();
		//CCDirector.sharedDirector().replaceScene(GameLayer.scene());
		
		return true;
	}

}
