package org.mirlab.tomatoshoot;

import java.util.LinkedList;

public class MIRFighter {	
	private int money;	
	private LinkedList<String> ownWeapons = new LinkedList<String>();
	private LinkedList<String> ownArmors = new LinkedList<String>();
	private LinkedList<String> ownProps = new LinkedList<String>();
	//private LinkedList<String> selectedWeapons = new LinkedList<String>();
	private String selectedWeapons[] = new String[2];
	private LinkedList<String> selectedArmors = new LinkedList<String>();
	private LinkedList<String> selectedProps = new LinkedList<String>();	
	private String userID;	
	
	protected MIRFighter() {
		this.money = 0;		
		this.userID = "MIR";
	}
	
	protected MIRFighter(String id, int money) {
		this.userID = id;
		this.money = money;
	}
	
	public void setMoney(int Money) {
		this.money = Money;
	}
	
	public int getMoney() {
		return this.money;
	}
	
	public void setID(String ID) {
		this.userID = ID;
	}
	
	public String getID() {
		return this.userID;
	}
	
	public void addOwnWeapons(String weapon) {
		ownWeapons.add(weapon);
	}
	
	public LinkedList<String> getOwnWeapons() {
		return ownWeapons;
	}
	
	public void addOwnArmors(String armor) {
		ownArmors.add(armor);
	}
	
	public LinkedList<String> getOwnArmors() {
		return ownArmors;
	}
	
	public void addOwnProps(String prop) {
		ownProps.add(prop);
	}
	
	public LinkedList<String> getOwnProps() {
		return ownProps;
	}

	public void setSelectedWeapon1(String selectedWeapon01) {
		//selectedWeapons.add(0, selectedWeapon01);		
		selectedWeapons[0] = String.copyValueOf(selectedWeapon01.toCharArray());		
	}	
	
	public void setSelectedWeapon2(String selectedWeapon02) {		
		//selectedWeapons.add(1, selectedWeapon02);
		selectedWeapons[1] = String.copyValueOf(selectedWeapon02.toCharArray());
	}
	
	//public LinkedList<String> getSelectedWeapons() {
	public String[] getSelectedWeapons() {
		return selectedWeapons;
	}

	public void setSelectedArmor1(String selectedArmor01) {
		selectedArmors.add(0, selectedArmor01);		
	}	
	
	public void setSelectedArmor2(String selectedArmor02) {		
		selectedArmors.add(1, selectedArmor02);
	}
	
	public LinkedList<String> getSelectedArmors() {
		return selectedArmors;
	}
	
	public void setSelectedProps(String selectedProp01, String selectedProp02) {
		selectedProps.add(1, selectedProp01);
		selectedProps.add(2, selectedProp02);
	}
	
	public LinkedList<String> getSelectedProps() {
		return selectedProps;
	}
	
}
